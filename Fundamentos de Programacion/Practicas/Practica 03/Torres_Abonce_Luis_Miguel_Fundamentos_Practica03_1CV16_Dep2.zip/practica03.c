#include "menu.h"

int main( int argc, char *argv ){
    menu();
    return 0;
}
