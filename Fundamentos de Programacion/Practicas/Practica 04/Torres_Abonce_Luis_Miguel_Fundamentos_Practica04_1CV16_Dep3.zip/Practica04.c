#include "menu.h"
#include "milibreriaio.h"

int main( int argc, char *argv ){
    menu();
    return 0;
}