package com.example.intercambios

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.intercambios.data.DatabaseHelper
import androidx.compose.ui.platform.LocalContext
import android.provider.ContactsContract
import android.util.Log
import android.widget.TimePicker
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.text.input.KeyboardType
import java.util.Calendar

@Composable
fun AdminScreen(
    exchangeId: String,
    onNavigateBack: () -> Unit,
    dbHelper: DatabaseHelper
) {
    val exchangeDetails = remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    val participants = remember { mutableStateListOf<Map<String, String>>() }
    val confirmedParticipants = remember { mutableStateListOf<Map<String, String>>() }
    val giftTopics = remember { mutableStateOf("") }
    val maxAmount = remember { mutableStateOf("") }
    val registrationDeadline = remember { mutableStateOf("") }
    val exchangeDate = remember { mutableStateOf("") }
    val location = remember { mutableStateOf("") }
    val time = remember { mutableStateOf("") }
    val comments = remember { mutableStateOf("") }
    val context = LocalContext.current

    var showConfirmed by remember { mutableStateOf(false) }
    var showNotConfirmed by remember { mutableStateOf(false) }
    val showDeleteDialog = remember { mutableStateOf(false) }
    val selectedGiftThemes = remember { mutableStateListOf<String>() }

    var showEditDialog by remember { mutableStateOf(false) }
    var editingParticipant by remember { mutableStateOf<Map<String, String>?>(null) }

    val editedName = remember { mutableStateOf("") }
    val editedCorreo = remember { mutableStateOf("") }
    val editedTelefono = remember { mutableStateOf("") }

    val pickContactLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickContact()
    ) { uri ->
        uri?.let {
            val contentResolver = context.contentResolver
            val cursor = contentResolver.query(
                it,
                arrayOf(ContactsContract.Contacts._ID, ContactsContract.Contacts.DISPLAY_NAME),
                null,
                null,
                null
            )
            cursor?.use {
                if (cursor.moveToFirst()) {
                    val contactIdIndex = cursor.getColumnIndex(ContactsContract.Contacts._ID)
                    val nameIndex = cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME)

                    val contactId = cursor.getString(contactIdIndex)
                    val name = cursor.getString(nameIndex) ?: "Nombre desconocido"

                    val emailCursor = contentResolver.query(
                        ContactsContract.CommonDataKinds.Email.CONTENT_URI,
                        arrayOf(ContactsContract.CommonDataKinds.Email.ADDRESS),
                        "${ContactsContract.CommonDataKinds.Email.CONTACT_ID} = ?",
                        arrayOf(contactId),
                        null
                    )
                    emailCursor?.use {
                        if (emailCursor.moveToFirst()) {
                            val emailIndex = emailCursor.getColumnIndex(ContactsContract.CommonDataKinds.Email.ADDRESS)
                            val email = emailCursor.getString(emailIndex)
                            if (!email.isNullOrEmpty()) {
                                if (participants.any { it["correo"] == email }) {
                                    Toast.makeText(context, "El contacto ya está en la lista.", Toast.LENGTH_SHORT).show()
                                } else {
                                    participants.add(
                                        mapOf(
                                            "nombre" to name,
                                            "correo" to email,
                                            "telefono" to "Teléfono no disponible" // Puedes agregar el teléfono si lo tienes
                                        )
                                    )
                                    Toast.makeText(context, "Participante agregado: $name", Toast.LENGTH_SHORT).show()
                                }
                            } else {
                                Toast.makeText(context, "El contacto no tiene correo electrónico.", Toast.LENGTH_SHORT).show()
                            }
                        } else {
                            Toast.makeText(context, "No se encontraron correos electrónicos para el contacto.", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        } ?: Toast.makeText(context, "No se seleccionó ningún contacto.", Toast.LENGTH_SHORT).show()
    }


    LaunchedEffect(Unit) {
        // Cargar detalles del intercambio desde la base de datos
        val details = dbHelper.getExchangeDetails(exchangeId)
        if (details != null) {
            exchangeDetails.value = details
            val dbParticipants = details["participants"]?.takeIf { it.isNotBlank() }?.let { rawData ->
                // Transformar los datos con regex
                val regex = """\{nombre=(.*?), correo=(.*?), telefono=(.*?)\}""".toRegex()
                regex.findAll(rawData).map { matchResult ->
                    mapOf(
                        "nombre" to matchResult.groupValues[1],
                        "correo" to matchResult.groupValues[2],
                        "telefono" to matchResult.groupValues[3]
                    )
                }.toList()
            } ?: emptyList()
            participants.addAll(dbParticipants)

            // Confirmados
            val dbConfirmed = details["participantsConfirm"]?.takeIf { it.isNotBlank() }?.let { rawData ->
                // Usamos regex para extraer los datos
                val regex = """\{nombre=(.*?), correo=(.*?), telefono=(.*?)\}""".toRegex()
                regex.findAll(rawData).map { matchResult ->
                    mapOf(
                        "nombre" to matchResult.groupValues[1],
                        "correo" to matchResult.groupValues[2],
                        "telefono" to matchResult.groupValues[3]
                    )
                }.toList()
            } ?: emptyList()

            confirmedParticipants.addAll(dbConfirmed)

            giftTopics.value = details["giftTopics"] ?: ""
            selectedGiftThemes.addAll(giftTopics.value.split(",").map { it.trim() }.filter { it.isNotEmpty() })
            maxAmount.value = details["maxAmount"] ?: ""
            registrationDeadline.value = details["registrationDeadline"] ?: ""
            exchangeDate.value = details["exchangeDate"] ?: ""
            location.value = details["location"] ?: ""
            time.value = details["time"] ?: ""
            comments.value = details["comments"] ?: ""
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize(),
        contentAlignment = Alignment.Center

    ) {
        Image(
            painter = painterResource(id = R.drawable.arbol),
            contentDescription = "Fondo de pantalla de administrador",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        Column(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .padding(16.dp)
                .background(Color.White.copy(alpha = 0.7f), shape = RoundedCornerShape(16.dp))
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Administrar Intercambio",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFB71C1C),
                modifier = Modifier.padding(bottom = 16.dp)
            )

            Text(
                text = "Intercambio ID: $exchangeId",
                fontSize = 20.sp,
                fontWeight = FontWeight.Medium,
                color = Color.Black,
                modifier = Modifier.padding(vertical = 8.dp)
            )
            // Botón para agregar participante
            Button(
                onClick = {
                    pickContactLauncher.launch(null)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF004D00))
            ) {
                Text(
                    text = "Agregar Participante",
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }

            Button(
                onClick = { showConfirmed = !showConfirmed },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF004D00))
            ) {
                Text(
                    text = if (showConfirmed) "Ocultar Participantes Confirmados" else "Mostrar Participantes Confirmados",
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }

            if (showConfirmed) {
                // Mostrar lista de participantes confirmados
                Column(modifier = Modifier.fillMaxWidth()) {
                    confirmedParticipants.forEachIndexed { index, participant ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .background(Color(0xFFF5F5F5), shape = RoundedCornerShape(8.dp))
                                .padding(12.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${index + 1}. ${participant["nombre"] ?: "Nombre desconocido"}",
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.Black
                                    )
                                    Text(
                                        text = "Correo: ${participant["correo"] ?: "Correo no disponible"}",
                                        fontSize = 14.sp,
                                        color = Color.Gray
                                    )
                                    Text(
                                        text = "Teléfono: ${participant["telefono"] ?: "Teléfono no disponible"}",
                                        fontSize = 14.sp,
                                        color = Color.Gray
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Button(
                onClick = { showNotConfirmed = !showNotConfirmed },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF004D00))
            ) {
                Text(
                    text = if (showNotConfirmed) "Ocultar Participantes No Confirmados" else "Mostrar Participantes No Confirmados",
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }

            if (showNotConfirmed) {
                // Filtrar participantes no confirmados
                val notConfirmedParticipants = participants.filter { participant ->
                    !confirmedParticipants.any { it["correo"] == participant["correo"] }
                }

                if (notConfirmedParticipants.isEmpty()) {
                    Text(
                        text = "No hay participantes no confirmados.",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                } else {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        notConfirmedParticipants.forEachIndexed { index, participant ->
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .background(Color(0xFFF5F5F5), shape = RoundedCornerShape(8.dp))
                                    .padding(12.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "${index + 1}. ${participant["nombre"] ?: "Nombre desconocido"}",
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.Black
                                        )
                                        Text(
                                            text = "Correo: ${participant["correo"] ?: "Correo no disponible"}",
                                            fontSize = 14.sp,
                                            color = Color.Gray
                                        )
                                        Text(
                                            text = "Teléfono: ${participant["telefono"] ?: "Teléfono no disponible"}",
                                            fontSize = 14.sp,
                                            color = Color.Gray
                                        )
                                    }
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Button(
                                            onClick = {
                                                editingParticipant = participant
                                                editedName.value = participant["nombre"] ?: ""
                                                editedCorreo.value = participant["correo"] ?: ""
                                                editedTelefono.value = participant["telefono"] ?: ""
                                                showEditDialog = true
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF004D00)),
                                            modifier = Modifier
                                                .fillMaxWidth(0.4f)
                                                .padding(bottom = 4.dp)
                                        ) {
                                            Text("Editar", color = Color.White)
                                        }
                                        Button(
                                            onClick = {
                                                participants.removeAt(index)
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                                            modifier = Modifier.fillMaxWidth(0.4f)
                                        ) {
                                            Text("Eliminar", color = Color.White)
                                        }
                                    }
                                }
                            }
                        }


                        if (showEditDialog && editingParticipant != null) {
                            AlertDialog(
                                onDismissRequest = { showEditDialog = false },
                                title = { Text("Editar Participante") },
                                text = {
                                    Column(modifier = Modifier.fillMaxWidth()) {
                                        OutlinedTextField(
                                            value = editedName.value,
                                            onValueChange = { editedName.value = it },
                                            label = { Text("Nombre") },
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                        OutlinedTextField(
                                            value = editedCorreo.value,
                                            onValueChange = { editedCorreo.value = it },
                                            label = { Text("Correo") },
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                        OutlinedTextField(
                                            value = editedTelefono.value,
                                            onValueChange = { editedTelefono.value = it },
                                            label = { Text("Teléfono") },
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                                },
                                confirmButton = {
                                    Button(
                                        onClick = {
                                            // Confirmar edición
                                            editingParticipant?.let { oldParticipant ->
                                                val updatedParticipant = mapOf(
                                                    "nombre" to editedName.value,
                                                    "correo" to editedCorreo.value,
                                                    "telefono" to editedTelefono.value
                                                )
                                                val index = participants.indexOf(oldParticipant)
                                                if (index != -1) {
                                                    participants[index] = updatedParticipant
                                                }
                                            }
                                            showEditDialog = false
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF004D00))
                                    ) {
                                        Text("Confirmar", color = Color.White)
                                    }
                                },
                                dismissButton = {
                                    Button(
                                        onClick = { showEditDialog = false },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                                    ) {
                                        Text("Cancelar", color = Color.White)
                                    }
                                }
                            )
                        }
                    }
                }
            }

            // Mostrar temas seleccionados
            selectedGiftThemes.forEachIndexed { index, theme ->
                OutlinedTextField(
                    value = theme,
                    onValueChange = { newTheme ->
                        if (newTheme.length <= 20) {
                            selectedGiftThemes[index] = newTheme
                        } else {
                            Toast.makeText(context, "Máximo 20 caracteres por tema", Toast.LENGTH_SHORT).show()
                        }
                    },
                    label = { Text("Tema ${index + 1}", color = Color.Black )},
                    textStyle = LocalTextStyle.current.copy(color = Color.Black),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                )
            }

            // Botón para agregar un tema
            if (selectedGiftThemes.size < 3) {
                Button(
                    onClick = {
                        selectedGiftThemes.add("")
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                ) {
                    Text("Agregar Tema")
                }
            } else {
                Text(
                    text = "Máximo de 3 temas alcanzado",
                    fontSize = 14.sp,
                    color = Color.Black,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            }

            OutlinedTextField(
                value = maxAmount.value,
                onValueChange = { maxAmount.value = it.filter { it.isDigit() } },
                label = { Text("Monto Máximo (en pesos)", color = Color.Black) },
                leadingIcon = { Text(text = "$", color = Color.Black) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                textStyle = LocalTextStyle.current.copy(color = Color.Black)
            )


            Text(
                text = "Fecha Límite de Inscripción",
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(vertical = 8.dp)
            )
            Row {
                Button(
                    onClick = {
                        val calendar = Calendar.getInstance()
                        DatePickerDialog(
                            context,
                            { _, year, month, dayOfMonth ->
                                registrationDeadline.value = "$dayOfMonth/${month + 1}/$year"
                            },
                            calendar.get(Calendar.YEAR),
                            calendar.get(Calendar.MONTH),
                            calendar.get(Calendar.DAY_OF_MONTH)
                        ).show()
                    },
                    modifier = Modifier.padding(end = 8.dp)
                ) {
                    Text(
                        if (registrationDeadline.value.isEmpty()) "Seleccionar Fecha" else registrationDeadline.value
                    )
                }
            }

            Text("Fecha y hora del intercambio", fontWeight = FontWeight.Bold)
            Row {
                // Botón para seleccionar la fecha del intercambio
                Button(
                    onClick = {
                        val calendar = Calendar.getInstance()
                        DatePickerDialog(
                            context,
                            { _, year, month, dayOfMonth ->
                                exchangeDate.value = "$dayOfMonth/${month + 1}/$year"
                            },
                            calendar.get(Calendar.YEAR),
                            calendar.get(Calendar.MONTH),
                            calendar.get(Calendar.DAY_OF_MONTH)
                        ).show()
                    },
                    modifier = Modifier.padding(end = 8.dp)
                ) {
                    Text(
                        if (exchangeDate.value.isEmpty()) "Seleccionar Fecha" else exchangeDate.value
                    )
                }

                // Botón para seleccionar la hora del intercambio
                Button(
                    onClick = {
                        val calendar = Calendar.getInstance()
                        TimePickerDialog(
                            context,
                            { _: TimePicker, hour, minute ->
                                time.value = String.format("%02d:%02d", hour, minute)
                            },
                            calendar.get(Calendar.HOUR_OF_DAY),
                            calendar.get(Calendar.MINUTE),
                            true
                        ).show()
                    },
                    modifier = Modifier.padding(start = 8.dp)
                ) {
                    Text(
                        if (time.value.isEmpty()) "Seleccionar Hora" else time.value
                    )
                }
            }

            // Campo de texto para ingresar el lugar del intercambio
            OutlinedTextField(
                value = location.value,
                onValueChange = { location.value = it },
                label = { Text("Lugar del intercambio", color = Color.Black) },
                modifier = Modifier.fillMaxWidth(),
                textStyle = LocalTextStyle.current.copy(color = Color.Black)
            )


            // Campo de texto para ingresar el lugar del intercambio
            OutlinedTextField(
                value = comments.value,
                onValueChange = { location.value = it },
                label = { Text("Comentarios", color = Color.Black) },
                modifier = Modifier.fillMaxWidth(),
                textStyle = LocalTextStyle.current.copy(color = Color.Black)
            )

            // Botones
            Button(
                onClick = {
                    giftTopics.value = selectedGiftThemes.joinToString(",")
                    dbHelper.updateExchange(
                        exchangeId = exchangeId,
                        participants = participants.joinToString(","),
                        participantsConfirm = confirmedParticipants.joinToString(","),
                        giftTopics = giftTopics.value,
                        maxAmount = maxAmount.value,
                        registrationDeadline = registrationDeadline.value,
                        exchangeDate = exchangeDate.value,
                        location = location.value,
                        time = time.value,
                        comments = comments.value
                    )
                    Toast.makeText(context, "Intercambio actualizado", Toast.LENGTH_SHORT).show()
                    onNavigateBack()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF004D00))
            ) {
                Text(
                    text = "Actualizar",
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    fontSize = 18.sp
                )
            }
            if (showDeleteDialog.value) {
                AlertDialog(
                    onDismissRequest = { showDeleteDialog.value = false },
                    title = { Text("Confirmar Eliminación") },
                    text = { Text("¿Está seguro de que desea borrar este intercambio?") },
                    confirmButton = {
                        Button(
                            onClick = {
                                val success = dbHelper.deleteExchange(exchangeId)
                                if (success) {
                                    Toast.makeText(context, "Intercambio eliminado", Toast.LENGTH_SHORT).show()
                                    showDeleteDialog.value = false
                                    onNavigateBack()
                                } else {
                                    Toast.makeText(context, "Error al eliminar el intercambio", Toast.LENGTH_SHORT).show()
                                    showDeleteDialog.value = false
                                }
                            }
                        ) {
                            Text("Sí")
                        }
                    },
                    dismissButton = {
                        Button(
                            onClick = { showDeleteDialog.value = false }
                        ) {
                            Text("No")
                        }
                    }
                )
            }

            // Botón de sorteo
            Button(
                onClick = {
                    // Verificar si hay suficientes participantes confirmados
                    val confirmedParticipants = confirmedParticipants.mapNotNull { participant ->
                        participant["correo"]?.let { dbHelper.getUserIdByEmail(it) }
                    }

                    if (confirmedParticipants.size < 2) {
                        Toast.makeText(context, "Debe haber al menos 2 participantes confirmados para realizar el sorteo.", Toast.LENGTH_SHORT).show()
                        return@Button
                    }

                    // Barajar participantes
                    val shuffledParticipants = confirmedParticipants.shuffled()

                    // Realizar asignaciones
                    for (i in shuffledParticipants.indices) {
                        val giverId = shuffledParticipants[i]
                        val receiverId = if (i == shuffledParticipants.lastIndex) shuffledParticipants[0] else shuffledParticipants[i + 1]
                        // Recuperar el tema existente, si lo hay
                        val existingAssignment = dbHelper.getAssignmentByUserAndExchange(exchangeId.toInt(), giverId)
                        val currentGiftTopic = existingAssignment?.get("gift_topic") ?: giftTopics.value.takeIf { it.isNotEmpty() }
                        ?: "Tema por Definir"
                        // Actualizar en la base de datos
                        val success = dbHelper.insertOrUpdateAssignment(
                            exchangeId.toInt(),
                            giverId,
                            receiverId,
                            giftTopic = currentGiftTopic
                        )
                        if (!success) {
                            Toast.makeText(context, "Error al realizar la asignación.", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                    }

                    // Notificar éxito
                    Toast.makeText(context, "¡Sorteo realizado con éxito!", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB71C1C))
            ) {
                Text(
                    text = "Sorteo",
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }

            Button(
                onClick = { showDeleteDialog.value = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
            ) {
                Text(
                    text = "Borrar Intercambio",
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    fontSize = 18.sp
                )
            }

            Button(
                onClick = onNavigateBack,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB71C1C))
            ) {
                Text(
                    text = "Regresar",
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    fontSize = 18.sp
                )
            }
        }
    }
}
