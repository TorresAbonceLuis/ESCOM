package com.example.intercambios

import android.util.Log
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.intercambios.data.DatabaseHelper
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import kotlin.math.log

@Composable
fun ClienteScreen(
    exchangeId: String,
    onNavigateBack: () -> Unit,
    dbHelper: DatabaseHelper,
    userEmail: String
) {
    val giftTopics = remember { mutableStateListOf<String>() } // Lista de temas
    val selectedGiftTopic = remember { mutableStateOf("") } // Tema seleccionado
    val maxAmount = remember { mutableStateOf("") }
    val registrationDeadline = remember { mutableStateOf("") }
    val exchangeDate = remember { mutableStateOf("") }
    val location = remember { mutableStateOf("") }
    val time = remember { mutableStateOf("") }
    val comments = remember { mutableStateOf("") }
    val assignedUserStatus = remember { mutableStateOf("Aún no asignado") }
    val context = LocalContext.current

    // Estado para la confirmación
    val confirmed = remember { mutableStateOf("No") } // Por defecto "No"
    val showConfirmButton = remember { mutableStateOf(true) }

    val userId = remember { mutableStateOf(0) } // Este valor debe ser cargado desde la BD
    LaunchedEffect(Unit) {
        val details = dbHelper.getExchangeDetails(exchangeId)
        if (details != null) {
            giftTopics.addAll(details["giftTopics"]?.split(",")?.map { it.trim() } ?: emptyList())
            maxAmount.value = details["maxAmount"] ?: ""
            registrationDeadline.value = details["registrationDeadline"] ?: ""
            exchangeDate.value = details["exchangeDate"] ?: ""
            location.value = details["location"] ?: ""
            time.value = details["time"] ?: ""
            comments.value = details["comments"] ?: ""
            userId.value = dbHelper.getUserIdByEmail(userEmail)
        }

        // Verificar si el usuario está confirmado en el intercambio
        val isConfirmed = dbHelper.isUserConfirmedInExchange(exchangeId, userEmail)
        if (isConfirmed) {
            confirmed.value = "Sí"
            showConfirmButton.value = false
        }

        // Verificar si ya existe un tema de regalo para este usuario en este intercambio
        val assignment = dbHelper.getAssignmentByUserAndExchange(exchangeId.toInt(), userId.value)
        if (assignment != null) {
            selectedGiftTopic.value = assignment["gift_topic"] ?: ""

            val assignedUserId = assignment["assigned_user_id"]?.toIntOrNull()
            assignedUserStatus.value = if (assignedUserId != null) {
                val assignedUserName = dbHelper.getUserNameById(assignedUserId)
                "Asignado a: $assignedUserName"
            } else {
                "Aún no asignado"
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFAFAFA)),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.arbol),
            contentDescription = "Fondo",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        Card(
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .padding(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.9f)),
            elevation = CardDefaults.cardElevation(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Detalles del Intercambio",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFD32F2F),
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                // Información del intercambio
                InfoRow(label = "Intercambio ID", value = exchangeId)
                InfoRow(label = "Monto Máximo", value = "$${maxAmount.value}")
                InfoRow(label = "Fecha Límite de Inscripción", value = registrationDeadline.value)
                InfoRow(label = "Fecha del Intercambio", value = exchangeDate.value)
                InfoRow(label = "Hora del Intercambio", value = time.value)
                InfoRow(label = "Lugar", value = location.value)
                if (comments.value.isNotEmpty()) {
                    InfoRow(label = "Comentarios", value = comments.value)
                }

                Spacer(modifier = Modifier.height(16.dp))
                // Mostrar el estado del usuario asignado
                Log.d("ClienteScreen", "assignedUserStatus: ${assignedUserStatus.value}")
                InfoRow(label = "Usuario Asignado", value = assignedUserStatus.value)

                Spacer(modifier = Modifier.height(16.dp))
                // Selección de tema de regalo
                Text(
                    text = "Seleccione un Tema de Regalo:",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF424242),
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Column {
                    giftTopics.forEach { topic ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            RadioButton(
                                selected = selectedGiftTopic.value == topic,
                                onClick = { selectedGiftTopic.value = topic },
                                colors = RadioButtonDefaults.colors(selectedColor = Color(0xFFD32F2F))
                            )
                            Text(
                                text = topic,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Normal,
                                color = Color(0xFF424242),
                                modifier = Modifier.padding(start = 8.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Botón Confirmar Tema
                Button(
                    onClick = {
                        if (selectedGiftTopic.value.isEmpty()) {
                            Toast.makeText(
                                context,
                                "Por favor, seleccione un tema de regalo.",
                                Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            val success = dbHelper.insertOrUpdateAssignment(
                                exchangeId = exchangeId.toInt(),
                                userId = userId.value,
                                assignedUserId = null, // Queda en blanco
                                giftTopic = selectedGiftTopic.value
                            )
                            if (success) {
                                Toast.makeText(
                                    context,
                                    "Tema de regalo actualizado exitosamente.",
                                    Toast.LENGTH_SHORT
                                ).show()
                            } else {
                                Toast.makeText(
                                    context,
                                    "Error al guardar el tema de regalo.",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF388E3C))
                ) {
                    Text(
                        text = "Confirmar Tema",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 18.sp
                    )
                }
                // Confirmación de usuario
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Confirmado:",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF424242)
                    )
                    Text(
                        text = confirmed.value,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (confirmed.value == "Sí") Color(0xFF388E3C) else Color(0xFFD32F2F)
                    )
                }

                // Botón Confirmar Participante
                if (showConfirmButton.value) {
                    Button(
                        onClick = {
                            val success = dbHelper.confirmParticipantInExchange(exchangeId, userEmail)
                            if (success) {
                                confirmed.value = "Sí"
                                showConfirmButton.value = false
                                Toast.makeText(context, "Usuario confirmado", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, "Error al confirmar", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF388E3C))
                    ) {
                        Text("Confirmar Participación", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    // Botón Cancelar Participación
                    Button(
                        onClick = {
                            val success = dbHelper.cancelParticipation(exchangeId, userEmail)
                            if (success) {
                                Toast.makeText(
                                    context,
                                    "Tu participación ha sido cancelada.",
                                    Toast.LENGTH_SHORT
                                ).show()
                                onNavigateBack() // Regresa a la pantalla anterior
                            } else {
                                Toast.makeText(
                                    context,
                                    "Error al cancelar la participación.",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                    ) {
                        Text(
                            text = "Cancelar Participación",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 18.sp
                        )
                    }
                }

                // Botón Regresar
                Button(
                    onClick = onNavigateBack,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F))
                ) {
                    Text(
                        text = "Regresar",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 18.sp
                    )
                }
            }
        }
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text("$label:", fontSize = 16.sp, color = Color(0xFF616161), fontWeight = FontWeight.Bold)
        Text(value, fontSize = 16.sp, color = Color(0xFF424242))
    }
}