package com.example.intercambios.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "intercambios.db"
        private const val DATABASE_VERSION = 4 // Se incrementó la versión de la base de datos

        // Tabla de usuarios
        const val TABLE_USERS = "users"
        const val COLUMN_ID = "id"
        const val COLUMN_NAME = "name"
        const val COLUMN_ALIAS = "alias"
        const val COLUMN_EMAIL = "email"
        const val COLUMN_PHONE = "phone"
        const val COLUMN_PASSWORD = "password"

        // Nueva tabla de intercambios
        const val TABLE_EXCHANGES = "exchanges"
        const val COLUMN_EXCHANGE_ID = "exchange_id"
        const val COLUMN_PARTICIPANTS = "participants"
        const val COLUMN_PARTICIPANTS_CONFIRM = "participants_confirm"
        const val COLUMN_GIFT_TOPICS = "gift_topics"
        const val COLUMN_MAX_AMOUNT = "max_amount"
        const val COLUMN_REGISTRATION_DEADLINE = "registration_deadline"
        const val COLUMN_EXCHANGE_DATE = "exchange_date"
        const val COLUMN_LOCATION = "location"
        const val COLUMN_TIME = "time"
        const val COLUMN_COMMENTS = "comments"
        const val ADMIN_EMAIL = "admin_email"

        // Tabla de asignaciones de intercambio
        const val TABLE_ASSIGNMENTS = "assignments"
        const val COLUMN_ASSIGNMENT_ID = "assignment_id"
        const val COLUMN_ASSIGNED_USER_ID = "assigned_user_id"
        const val COLUMN_GIFT_TOPIC = "gift_topic"

    }

    override fun onCreate(db: SQLiteDatabase) {
        // Crear la tabla de usuarios
        val createUsersTableQuery = """
            CREATE TABLE $TABLE_USERS (
                $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_NAME TEXT NOT NULL,
                $COLUMN_ALIAS TEXT NOT NULL,
                $COLUMN_EMAIL TEXT UNIQUE NOT NULL,
                $COLUMN_PHONE TEXT NOT NULL,
                $COLUMN_PASSWORD TEXT NOT NULL
            )
        """
        db.execSQL(createUsersTableQuery)

        // Crear la tabla de intercambios
        val createExchangesTableQuery = """
            CREATE TABLE $TABLE_EXCHANGES (
                $COLUMN_EXCHANGE_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_PARTICIPANTS TEXT NOT NULL,
                $COLUMN_PARTICIPANTS_CONFIRM TEXT,
                $COLUMN_GIFT_TOPICS TEXT NOT NULL,
                $COLUMN_MAX_AMOUNT REAL NOT NULL,
                $COLUMN_REGISTRATION_DEADLINE TEXT NOT NULL,
                $COLUMN_EXCHANGE_DATE TEXT NOT NULL,
                $COLUMN_LOCATION TEXT NOT NULL,
                $COLUMN_TIME TEXT NOT NULL,
                $COLUMN_COMMENTS TEXT,
                $ADMIN_EMAIL TEXT NOT NULL
            )
        """
        db.execSQL(createExchangesTableQuery)

        // Crear la tabla de asignaciones
        val createAssignmentsTableQuery = """
        CREATE TABLE $TABLE_ASSIGNMENTS (
            $COLUMN_ASSIGNMENT_ID INTEGER PRIMARY KEY AUTOINCREMENT,
            $COLUMN_EXCHANGE_ID INTEGER NOT NULL,
            $COLUMN_ID INTEGER NOT NULL,
            $COLUMN_ASSIGNED_USER_ID INTEGER NOT NULL,
            $COLUMN_GIFT_TOPIC TEXT NOT NULL,
            FOREIGN KEY ($COLUMN_EXCHANGE_ID) REFERENCES $TABLE_EXCHANGES($COLUMN_EXCHANGE_ID),
            FOREIGN KEY ($COLUMN_ID) REFERENCES $TABLE_USERS($COLUMN_ID),
            FOREIGN KEY ($COLUMN_ASSIGNED_USER_ID) REFERENCES $TABLE_USERS($COLUMN_ID)
        )
        """
        db.execSQL(createAssignmentsTableQuery)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 4) { // Cambiar a la versión adecuada de tu base de datos
            val createAssignmentsTableQuery = """
            CREATE TABLE $TABLE_ASSIGNMENTS (
                $COLUMN_ASSIGNMENT_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_EXCHANGE_ID INTEGER NOT NULL,
                $COLUMN_ID INTEGER NOT NULL,
                $COLUMN_ASSIGNED_USER_ID INTEGER,
                $COLUMN_GIFT_TOPIC TEXT NOT NULL,
                FOREIGN KEY ($COLUMN_EXCHANGE_ID) REFERENCES $TABLE_EXCHANGES($COLUMN_EXCHANGE_ID),
                FOREIGN KEY ($COLUMN_ID) REFERENCES $TABLE_USERS($COLUMN_ID),
                FOREIGN KEY ($COLUMN_ASSIGNED_USER_ID) REFERENCES $TABLE_USERS($COLUMN_ID)
            )
        """
            db.execSQL(createAssignmentsTableQuery)
        }
    }


    // Método para registrar un usuario
    fun registerUser(name: String, alias: String, email: String, phone: String, password: String,): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_NAME, name)
            put(COLUMN_ALIAS, alias)
            put(COLUMN_EMAIL, email)
            put(COLUMN_PHONE, phone)
            put(COLUMN_PASSWORD, password)
        }
        val result = db.insert(TABLE_USERS, null, values)
        return result != -1L
    }

    // Método para iniciar sesión
    fun loginUser(email: String, password: String): Boolean {
        val db = readableDatabase
        val query = "SELECT * FROM $TABLE_USERS WHERE $COLUMN_EMAIL = ? AND $COLUMN_PASSWORD = ?"
        val cursor = db.rawQuery(query, arrayOf(email, password))
        val exists = cursor.moveToFirst()
        cursor.close()
        return exists
    }

    // Verificar si el correo está registrado
    fun isEmailRegistered(email: String): Boolean {
        val db = readableDatabase
        val query = "SELECT * FROM $TABLE_USERS WHERE $COLUMN_EMAIL = ?"
        val cursor = db.rawQuery(query, arrayOf(email))
        val exists = cursor.moveToFirst()
        cursor.close()
        return exists
    }

    // Método para registrar un intercambio
    fun registerExchange(
        participants: String, // Lista de correos separados por coma
        participantsConfirm: String = "",
        giftTopics: String,
        maxAmount: Double,
        registrationDeadline: String,
        exchangeDate: String,
        location: String,
        time: String,
        comments: String,
        email: String?// Correo del administrador
    ): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_PARTICIPANTS, participants) // Puedes almacenar una lista separada por comas
            // Si participantsConfirm está vacío, insertar null en la columna
            if (participantsConfirm.isEmpty()) {
                putNull(COLUMN_PARTICIPANTS_CONFIRM)
            } else {
                put(COLUMN_PARTICIPANTS_CONFIRM, participantsConfirm)
            }
            put(COLUMN_GIFT_TOPICS, giftTopics)
            put(COLUMN_MAX_AMOUNT, maxAmount)
            put(COLUMN_REGISTRATION_DEADLINE, registrationDeadline)
            put(COLUMN_EXCHANGE_DATE, exchangeDate)
            put(COLUMN_LOCATION, location)
            put(COLUMN_TIME, time)
            put(COLUMN_COMMENTS, comments)
            put(ADMIN_EMAIL, email)
        }
        val result = db.insert(TABLE_EXCHANGES, null, values)
        return result != -1L
    }
    // Método para obtener el próximo ID disponible de intercambio
    fun getNextExchangeId(): Int {
        val db = readableDatabase
        val query = "SELECT MAX($COLUMN_EXCHANGE_ID) AS max_id FROM $TABLE_EXCHANGES"
        val cursor = db.rawQuery(query, null)
        var nextId = 1 // El primer ID disponible por defecto

        cursor?.use {
            if (it.moveToFirst()) {
                val maxId = it.getInt(it.getColumnIndexOrThrow("max_id"))
                if (maxId > 0) {
                    nextId = maxId + 1
                }
            }
        }
        return nextId
    }

    fun getAdminExchanges(userEmail: String): List<String> {
        val db = readableDatabase
        val query = "SELECT $COLUMN_EXCHANGE_ID FROM $TABLE_EXCHANGES WHERE $ADMIN_EMAIL = ?"
        val cursor = db.rawQuery(query, arrayOf(userEmail))
        val adminExchanges = mutableListOf<String>()

        cursor?.use {
            while (it.moveToNext()) {
                val exchangeId = it.getString(it.getColumnIndexOrThrow(COLUMN_EXCHANGE_ID))
                adminExchanges.add(exchangeId)
            }
        }
        return adminExchanges
    }

    fun getInvitedExchanges(userEmail: String): List<String> {
        val db = readableDatabase
        val query = """
        SELECT $COLUMN_EXCHANGE_ID 
        FROM $TABLE_EXCHANGES 
        WHERE $COLUMN_PARTICIPANTS LIKE ? OR $COLUMN_PARTICIPANTS_CONFIRM LIKE ?
    """
        val cursor = db.rawQuery(query, arrayOf("%$userEmail%", "%$userEmail%"))
        val invitedExchangeIds = mutableListOf<String>()

        cursor?.use {
            while (it.moveToNext()) {
                val exchangeId = it.getString(it.getColumnIndexOrThrow(COLUMN_EXCHANGE_ID))
                invitedExchangeIds.add(exchangeId)
            }
        }

        return invitedExchangeIds.distinct() // Evita IDs duplicados
    }

    fun deleteExchange(exchangeId: String): Boolean {
        val db = writableDatabase
        val rowsDeleted = db.delete(
            TABLE_EXCHANGES,
            "$COLUMN_EXCHANGE_ID = ?",
            arrayOf(exchangeId)
        )
        return rowsDeleted > 0
    }
    fun getExchangeDetails(exchangeId: String): Map<String, String>? {
        val db = readableDatabase
        val query = "SELECT * FROM $TABLE_EXCHANGES WHERE $COLUMN_EXCHANGE_ID = ?"
        val cursor = db.rawQuery(query, arrayOf(exchangeId))
        return if (cursor.moveToFirst()) {
            val details = mutableMapOf<String, String>()
            details["participants"] = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PARTICIPANTS))
            details["participantsConfirm"] = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PARTICIPANTS_CONFIRM))
            details["giftTopics"] = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_GIFT_TOPICS))
            details["maxAmount"] = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_MAX_AMOUNT))
            details["registrationDeadline"] = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_REGISTRATION_DEADLINE))
            details["exchangeDate"] = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_EXCHANGE_DATE))
            details["location"] = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_LOCATION))
            details["time"] = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TIME))
            details["comments"] = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_COMMENTS))
            cursor.close()
            details
        } else {
            cursor.close()
            null
        }
    }

    fun updateExchange(
        exchangeId: String,
        participants: String,
        participantsConfirm: String,
        giftTopics: String,
        maxAmount: String,
        registrationDeadline: String,
        exchangeDate: String,
        location: String,
        time: String,
        comments: String
    ): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_PARTICIPANTS, participants)
            put(COLUMN_PARTICIPANTS_CONFIRM, participantsConfirm)
            put(COLUMN_GIFT_TOPICS, giftTopics)
            put(COLUMN_MAX_AMOUNT, maxAmount)
            put(COLUMN_REGISTRATION_DEADLINE, registrationDeadline)
            put(COLUMN_EXCHANGE_DATE, exchangeDate)
            put(COLUMN_LOCATION, location)
            put(COLUMN_TIME, time)
            put(COLUMN_COMMENTS, comments)
        }
        val rowsUpdated = db.update(TABLE_EXCHANGES, values, "$COLUMN_EXCHANGE_ID = ?", arrayOf(exchangeId))
        return rowsUpdated > 0
    }

    fun addParticipantToExchange(exchangeId: String, userEmail: String): Boolean {
        val db = writableDatabase
        var success = false

        // Primero, verificar si el intercambio existe
        val query = "SELECT $COLUMN_PARTICIPANTS FROM $TABLE_EXCHANGES WHERE $COLUMN_EXCHANGE_ID = ?"
        val cursor = db.rawQuery(query, arrayOf(exchangeId))

        cursor?.use {
            if (it.moveToFirst()) {
                // Obtener los participantes actuales
                val currentParticipants = it.getString(it.getColumnIndexOrThrow(COLUMN_PARTICIPANTS)) ?: ""

                // Verificar si el usuario ya está en la lista de participantes
                if (currentParticipants.split(",").map { it.trim() }.contains(userEmail)) {
                    // Si el usuario ya está en la lista, no hacemos nada
                    success = false
                } else {
                    // Agregar el nuevo correo a la lista de participantes
                    val updatedParticipants = if (currentParticipants.isEmpty()) {
                        userEmail
                    } else {
                        "$currentParticipants, $userEmail"
                    }

                    // Actualizar la tabla con la nueva lista de participantes
                    val values = ContentValues().apply {
                        put(COLUMN_PARTICIPANTS, updatedParticipants)
                    }
                    val rowsUpdated = db.update(
                        TABLE_EXCHANGES,
                        values,
                        "$COLUMN_EXCHANGE_ID = ?",
                        arrayOf(exchangeId)
                    )
                    success = rowsUpdated > 0
                }
            }
        }
        cursor.close()
        return success
    }
    fun confirmParticipantInExchange(exchangeId: String, userEmail: String): Boolean {
        val db = writableDatabase
        var success = false

        // Obtener las columnas participants y participants_confirm
        val query = """
        SELECT $COLUMN_PARTICIPANTS, $COLUMN_PARTICIPANTS_CONFIRM 
        FROM $TABLE_EXCHANGES 
        WHERE $COLUMN_EXCHANGE_ID = ?
    """
        val cursor = db.rawQuery(query, arrayOf(exchangeId))

        cursor?.use {
            if (it.moveToFirst()) {
                val currentParticipants = it.getString(it.getColumnIndexOrThrow(COLUMN_PARTICIPANTS)) ?: ""
                val currentConfirmed = it.getString(it.getColumnIndexOrThrow(COLUMN_PARTICIPANTS_CONFIRM)) ?: ""

                // Usar regex para obtener participantes en formato nombre, correo y teléfono
                val participantRegex = """\{nombre=(.*?), correo=(.*?), telefono=(.*?)\}""".toRegex()
                val participantsList = participantRegex.findAll(currentParticipants).map { it.value }.toMutableList()
                val confirmedList = participantRegex.findAll(currentConfirmed).map { it.value }.toMutableList()

                // Encontrar el participante en la lista de no confirmados
                val participantToConfirm = participantsList.firstOrNull { it.contains("correo=$userEmail") }

                if (participantToConfirm != null) {
                    // Remover de la lista de no confirmados
                    participantsList.remove(participantToConfirm)

                    // Agregar a la lista de confirmados
                    confirmedList.add(participantToConfirm)

                    // Actualizar la base de datos
                    val values = ContentValues().apply {
                        put(COLUMN_PARTICIPANTS, participantsList.joinToString(","))
                        put(COLUMN_PARTICIPANTS_CONFIRM, confirmedList.joinToString(","))
                    }

                    val rowsUpdated = db.update(
                        TABLE_EXCHANGES,
                        values,
                        "$COLUMN_EXCHANGE_ID = ?",
                        arrayOf(exchangeId)
                    )

                    success = rowsUpdated > 0
                }
            }
        }
        cursor.close()
        return success
    }
    fun isUserConfirmedInExchange(exchangeId: String, userEmail: String): Boolean {
        val db = readableDatabase
        val query = """
        SELECT $COLUMN_PARTICIPANTS_CONFIRM 
        FROM $TABLE_EXCHANGES 
        WHERE $COLUMN_EXCHANGE_ID = ?
    """
        val cursor = db.rawQuery(query, arrayOf(exchangeId))
        var isConfirmed = false

        cursor?.use {
            if (it.moveToFirst()) {
                val confirmedParticipants = it.getString(it.getColumnIndexOrThrow(COLUMN_PARTICIPANTS_CONFIRM)) ?: ""

                // Log para depuración
                android.util.Log.d("DEBUG_PARTICIPANTS", "Confirmed Participants: $confirmedParticipants")

                if (confirmedParticipants.isNotEmpty()) {
                    val participantRegex = """\{nombre=.*?, correo=(.*?), telefono=.*?\}""".toRegex()

                    participantRegex.findAll(confirmedParticipants).forEach { matchResult ->
                        val correoBD = matchResult.groupValues[1].trim().lowercase() // Normalizamos
                        val correoUsuario = userEmail.trim().lowercase() // Normalizamos

                        android.util.Log.d("DEBUG_PARTICIPANTS", "Found Email: $correoBD, User Email: $correoUsuario")

                        if (correoBD == correoUsuario) {
                            isConfirmed = true
                            return@forEach
                        }
                    }
                }
            }
        }

        android.util.Log.d("DEBUG_PARTICIPANTS", "Is Confirmed: $isConfirmed for Email: $userEmail")
        return isConfirmed
    }

    fun insertAssignment(exchangeId: Int, userId: Int, assignedUserId: Int, giftTopic: String): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_EXCHANGE_ID, exchangeId)
            put(COLUMN_ID, userId)
            put(COLUMN_ASSIGNED_USER_ID, assignedUserId)
            put(COLUMN_GIFT_TOPIC, giftTopic)
        }
        val result = db.insert(TABLE_ASSIGNMENTS, null, values)
        return result != -1L
    }

    fun getUserIdByEmail(email: String): Int {
        val db = readableDatabase
        val query = "SELECT id FROM users WHERE email = ?"
        val cursor = db.rawQuery(query, arrayOf(email))
        var userId = -1
        cursor?.use {
            if (it.moveToFirst()) {
                userId = it.getInt(it.getColumnIndexOrThrow("id"))
            }
        }
        return userId
    }
    fun getAssignmentByUserAndExchange(exchangeId: Int, userId: Int): Map<String, String>? {
        val db = readableDatabase
        val query = """
        SELECT * FROM assignments WHERE exchange_id = ? AND id = ?
    """
        val cursor = db.rawQuery(query, arrayOf(exchangeId.toString(), userId.toString()))
        return if (cursor.moveToFirst()) {
            val assignment = mutableMapOf<String, String>()
            assignment["gift_topic"] = cursor.getString(cursor.getColumnIndexOrThrow("gift_topic"))
            assignment["assigned_user_id"] = cursor.getString(cursor.getColumnIndexOrThrow("assigned_user_id"))
            cursor.close()
            assignment
        } else {
            cursor.close()
            null
        }
    }

    fun insertOrUpdateAssignment(exchangeId: Int, userId: Int, assignedUserId: Int?, giftTopic: String): Boolean {
        val db = writableDatabase
        val query = """
        SELECT * FROM assignments WHERE exchange_id = ? AND id = ?
    """
        val cursor = db.rawQuery(query, arrayOf(exchangeId.toString(), userId.toString()))
        val exists = cursor.moveToFirst()
        cursor.close()

        val values = ContentValues().apply {
            put("exchange_id", exchangeId)
            put("id", userId)
            put("assigned_user_id", assignedUserId) // Puede ser null
            put("gift_topic", giftTopic)
        }

        return if (exists) {
            val rowsUpdated = db.update(
                "assignments",
                values,
                "exchange_id = ? AND id = ?",
                arrayOf(exchangeId.toString(), userId.toString())
            )
            rowsUpdated > 0
        } else {
            val result = db.insert("assignments", null, values)
            result != -1L
        }
    }

    fun cancelParticipation(exchangeId: String, userEmail: String): Boolean {
        val db = writableDatabase
        var success = false

        val query = """
        SELECT $COLUMN_PARTICIPANTS, $COLUMN_PARTICIPANTS_CONFIRM 
        FROM $TABLE_EXCHANGES 
        WHERE $COLUMN_EXCHANGE_ID = ?
    """
        val cursor = db.rawQuery(query, arrayOf(exchangeId))

        cursor?.use {
            if (it.moveToFirst()) {
                val currentParticipants = it.getString(it.getColumnIndexOrThrow(COLUMN_PARTICIPANTS)) ?: ""
                val currentConfirmed = it.getString(it.getColumnIndexOrThrow(COLUMN_PARTICIPANTS_CONFIRM)) ?: ""

                val participantRegex = """\{nombre=.*?, correo=$userEmail, telefono=.*?\}""".toRegex()

                val updatedParticipants = currentParticipants.replace(participantRegex, "").trim().trim(',')
                val updatedConfirmed = currentConfirmed.replace(participantRegex, "").trim().trim(',')

                val values = ContentValues().apply {
                    put(COLUMN_PARTICIPANTS, updatedParticipants)
                    put(COLUMN_PARTICIPANTS_CONFIRM, updatedConfirmed)
                }

                val rowsUpdated = db.update(
                    TABLE_EXCHANGES,
                    values,
                    "$COLUMN_EXCHANGE_ID = ?",
                    arrayOf(exchangeId)
                )
                success = rowsUpdated > 0
            }
        }
        cursor.close()
        return success
    }

    fun getUserNameById(userId: Int): String {
        val db = readableDatabase
        val query = "SELECT $COLUMN_NAME FROM $TABLE_USERS WHERE $COLUMN_ID = ?"
        val cursor = db.rawQuery(query, arrayOf(userId.toString()))
        var userName = "Desconocido"
        cursor?.use {
            if (it.moveToFirst()) {
                userName = it.getString(it.getColumnIndexOrThrow(COLUMN_NAME))
            }
        }
        return userName
    }
}
