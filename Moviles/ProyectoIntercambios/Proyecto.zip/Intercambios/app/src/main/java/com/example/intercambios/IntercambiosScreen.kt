package com.example.intercambios

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.os.Build
import android.provider.ContactsContract
import android.widget.TimePicker
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.text.input.KeyboardType
import java.util.*
import androidx.compose.ui.platform.LocalContext
import com.example.intercambios.data.DatabaseHelper

@RequiresApi(Build.VERSION_CODES.N)
@Composable
fun IntercambiosScreen(
    onNavigateToNextScreen: () -> Unit,
    onNavigateToParticipantes: () -> Unit,
    dbHelper: DatabaseHelper,
    userEmail: String
) {
    val giftThemes = remember { mutableStateListOf<String>()}
    val maxAmount = remember { mutableStateOf("") }
    val exchangeDate1 = remember { mutableStateOf("") } // Fecha para el primer calendario
    val exchangeDate2 = remember { mutableStateOf("") } // Fecha para el segundo calendario
    val exchangeTime2 = remember { mutableStateOf("") } // Hora para el segundo calendario
    val exchangeLocation = remember { mutableStateOf("") }
    val additionalComments = remember { mutableStateOf("") }
    val nextExchangeId = remember { mutableStateOf(0) }


    val context = LocalContext.current
    var showParticipants by remember { mutableStateOf(false) }
    val participants = remember { mutableStateListOf<Map<String, String>>() }

    val newParticipantName = remember { mutableStateOf("") }
    val newParticipantEmail = remember { mutableStateOf("") }
    val newParticipantPhone = remember { mutableStateOf("") }

    // Launcher para seleccionar contactos
    val pickContactLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickContact()
    ) { uri ->
        uri?.let {
            val contentResolver = context.contentResolver

            // Recuperar el ID del contacto seleccionado
            val cursor = contentResolver.query(
                it,
                arrayOf(ContactsContract.Contacts._ID, ContactsContract.Contacts.DISPLAY_NAME),
                null,
                null,
                null
            )
            cursor?.use {
                if (cursor.moveToFirst()) {
                    val contactIdIndex = cursor.getColumnIndex(ContactsContract.Contacts._ID)
                    val nameIndex = cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME)

                    val contactId = cursor.getString(contactIdIndex)
                    val name = cursor.getString(nameIndex) ?: "Nombre desconocido"

                    // Recuperar correo electrónico
                    val emailCursor = contentResolver.query(
                        ContactsContract.CommonDataKinds.Email.CONTENT_URI,
                        arrayOf(ContactsContract.CommonDataKinds.Email.ADDRESS),
                        "${ContactsContract.CommonDataKinds.Email.CONTACT_ID} = ?",
                        arrayOf(contactId),
                        null
                    )

                    emailCursor?.use {
                        if (emailCursor.moveToFirst()) {
                            val emailIndex =
                                emailCursor.getColumnIndex(ContactsContract.CommonDataKinds.Email.ADDRESS)
                            val email = emailCursor.getString(emailIndex) ?: "Correo no disponible"

                            // Recuperar teléfono
                            val phoneCursor = contentResolver.query(
                                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                                arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                                "${ContactsContract.CommonDataKinds.Phone.CONTACT_ID} = ?",
                                arrayOf(contactId),
                                null
                            )

                            val phone = phoneCursor?.use {
                                if (phoneCursor.moveToFirst()) {
                                    val phoneIndex =
                                        phoneCursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                                    phoneCursor.getString(phoneIndex)
                                } else {
                                    "Teléfono no disponible"
                                }
                            } ?: "Teléfono no disponible"

                            // Verificar si ya existe un participante con el mismo correo
                            if (participants.any { it["correo"] == email }) {
                                Toast.makeText(context, "El contacto ya está en la lista.", Toast.LENGTH_SHORT).show()
                            } else {
                                // Agregar el contacto con los datos recuperados
                                participants.add(
                                    mapOf(
                                        "nombre" to name,
                                        "correo" to email,
                                        "telefono" to phone
                                    )
                                )
                                Toast.makeText(context, "Participante agregado: $name", Toast.LENGTH_SHORT).show()
                            }
                        } else {
                            Toast.makeText(context, "El contacto no tiene correo electrónico.", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        } ?: Toast.makeText(context, "No se seleccionó ningún contacto.", Toast.LENGTH_SHORT).show()
    }


    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        // Imagen de fondo
        Image(
            painter = painterResource(id = R.drawable.arbol),
            contentDescription = "Fondo de intercambios",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        Column(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .padding(16.dp)
                .background(Color.White.copy(alpha = 0.7f), shape = RoundedCornerShape(16.dp))
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Box 1: Crear Intercambio, Clave única y Agregar Participante
            LaunchedEffect(Unit) {
                nextExchangeId.value = dbHelper.getNextExchangeId()
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
                    .background(Color(0xFFEFEFEF), shape = RoundedCornerShape(8.dp))
                    .padding(16.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "Crear Intercambio",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFB71C1C),
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    Text(
                        text = "Clave único del intercambio: ${nextExchangeId.value}",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF004D00),
                        modifier = Modifier.padding(bottom = 16.dp)
                    )
                }

            }

            // Box 2: Participantes, Monto
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
                    .background(Color(0xFFEFEFEF), shape = RoundedCornerShape(8.dp))
                    .padding(16.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    // Botón para mostrar participantes
                    Button(
                        onClick = {
                            showParticipants = !showParticipants
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF004D00))
                    ) {
                        Text(
                            text = if (showParticipants) "Ocultar Participantes" else "Mostrar Participantes",
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (showParticipants) {
                        OutlinedTextField(
                            value = newParticipantName.value,
                            onValueChange = { newParticipantName.value = it },
                            label = { Text("Nombre del Participante", color = Color.Black) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            textStyle = LocalTextStyle.current.copy(color = Color.Black)
                        )
                        OutlinedTextField(
                            value = newParticipantEmail.value,
                            onValueChange = { newParticipantEmail.value = it },
                            label = { Text("Correo del Participante", color = Color.Black) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            textStyle = LocalTextStyle.current.copy(color = Color.Black)
                        )
                        OutlinedTextField(
                            value = newParticipantPhone.value,
                            onValueChange = { newParticipantPhone.value = it },
                            label = { Text("Teléfono del Participante", color = Color.Black) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            textStyle = LocalTextStyle.current.copy(color = Color.Black)
                        )

                        Button(
                            onClick = {
                                val name = newParticipantName.value.trim()
                                val email = newParticipantEmail.value.trim()
                                val phone = newParticipantPhone.value.trim()

                                if (name.isNotEmpty() && email.isNotEmpty() && phone.isNotEmpty()) {
                                    if (android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                                        participants.add(
                                            mapOf(
                                                "nombre" to name,
                                                "correo" to email,
                                                "telefono" to phone
                                            )
                                        )
                                        newParticipantName.value = ""
                                        newParticipantEmail.value = ""
                                        newParticipantPhone.value = ""
                                        Toast.makeText(context, "Participante agregado", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, "Correo no válido", Toast.LENGTH_SHORT).show()
                                    }
                                } else {
                                    Toast.makeText(context, "Completa todos los campos", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF388E3C))
                        ) {
                            Text(
                                text = "Confirmar",
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 18.sp
                            )
                        }
                        // Botón para agregar participante
                        Button(
                            onClick = {
                                pickContactLauncher.launch(null)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF004D00))
                        ) {
                            Text(
                                text = "Abrir Contactos",
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Column(modifier = Modifier.fillMaxWidth()) {
                            participants.forEachIndexed { index, participant ->
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                        .background(Color(0xFFF5F5F5), shape = RoundedCornerShape(8.dp))
                                        .padding(12.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text = "${index + 1}. ${participant["nombre"]}",
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.Black,
                                            modifier = Modifier.weight(1f)
                                        )
                                        Column {
                                            Text(
                                                text = "Correo: ${participant["correo"]}",
                                                fontSize = 14.sp,
                                                color = Color.Gray
                                            )
                                            Text(
                                                text = "Teléfono: ${participant["telefono"]}",
                                                fontSize = 14.sp,
                                                color = Color.Gray
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Box 3: Temas de regalo, Fecha, Hora, Lugar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
                    .background(Color(0xFFEFEFEF), shape = RoundedCornerShape(8.dp))
                    .padding(16.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "Temas de los Regalos",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    giftThemes.forEachIndexed { index, gift ->
                        OutlinedTextField(
                            value = gift,
                            onValueChange = {
                                if (it.length <= 20) {
                                    giftThemes[index] = it
                                } else {
                                    Toast.makeText(context, "Máximo 20 caracteres por tema", Toast.LENGTH_SHORT).show()
                                }
                            },
                            label = { Text("Tema ${index + 1}", color = Color.Black) },
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            textStyle = LocalTextStyle.current.copy(color = Color.Black)
                        )
                    }

                    if (giftThemes.size < 3) {
                        Button(
                            onClick = {
                                giftThemes.add("")
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF388E3C))
                        ) {
                            Text(text = "Agregar Tema", color = Color.White)
                        }
                    } else {
                        Text(
                            text = "Máximo de 3 temas alcanzado",
                            fontSize = 14.sp,
                            color = Color.Gray,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = maxAmount.value,
                        onValueChange = { maxAmount.value = it.filter { it.isDigit() } },
                        label = { Text("Monto Máximo (en pesos)", color = Color.Black, fontSize = 13.sp) },
                        leadingIcon = { Text(text = "$", color = Color.Black) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = LocalTextStyle.current.copy(color = Color.Black)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Limite de Fecha para inscripción", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Row {
                        Button(
                            onClick = {
                                val calendar = Calendar.getInstance()
                                DatePickerDialog(
                                    context,
                                    { _, year, month, dayOfMonth ->
                                        exchangeDate1.value = "$dayOfMonth/${month + 1}/$year"
                                    },
                                    calendar.get(Calendar.YEAR),
                                    calendar.get(Calendar.MONTH),
                                    calendar.get(Calendar.DAY_OF_MONTH)
                                ).show()
                            },
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Text(
                                if (exchangeDate1.value.isEmpty()) "Fecha 1" else exchangeDate1.value
                            )
                        }
                    }

                    Text("Fecha y hora del intercambio", fontWeight = FontWeight.Bold)
                    Row {
                        Button(
                            onClick = {
                                val calendar = Calendar.getInstance()
                                DatePickerDialog(
                                    context,
                                    { _, year, month, dayOfMonth ->
                                        exchangeDate2.value = "$dayOfMonth/${month + 1}/$year"
                                    },
                                    calendar.get(Calendar.YEAR),
                                    calendar.get(Calendar.MONTH),
                                    calendar.get(Calendar.DAY_OF_MONTH)
                                ).show()
                            },
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Text(
                                if (exchangeDate2.value.isEmpty()) "Fecha 2" else exchangeDate2.value
                            )
                        }

                        Button(
                            onClick = {
                                val calendar = Calendar.getInstance()
                                TimePickerDialog(
                                    context,
                                    { _: TimePicker, hour, minute ->
                                        exchangeTime2.value = "$hour:$minute"
                                    },
                                    calendar.get(Calendar.HOUR_OF_DAY),
                                    calendar.get(Calendar.MINUTE),
                                    true
                                ).show()
                            },
                            modifier = Modifier.padding(start = 8.dp)
                        ) {
                            Text(
                                if (exchangeTime2.value.isEmpty()) "Hora 2" else exchangeTime2.value
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                    }
                    // Campo de texto para ingresar el lugar
                    OutlinedTextField(
                        value = exchangeLocation.value,
                        onValueChange = { exchangeLocation.value = it },
                        label = { Text("Lugar del intercambio", color = Color.Black) },
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = LocalTextStyle.current.copy(color = Color.Black)
                    )
                }
            }
            // Box 4: Comentarios, Botón Guardar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
                    .background(Color(0xFFEFEFEF), shape = RoundedCornerShape(8.dp))
                    .padding(16.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    // Comentarios adicionales
                    OutlinedTextField(
                        value = additionalComments.value,
                        onValueChange = { additionalComments.value = it },
                        label = { Text("Comentarios Adicionales", color = Color.Black) },
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = LocalTextStyle.current.copy(color = Color.Black) // Color negro para el texto
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            // Verifica que los campos necesarios no estén vacíos antes de guardar
                            if (participants.isNotEmpty() && exchangeDate1.value.isNotEmpty() && exchangeDate2.value.isNotEmpty() &&
                                maxAmount.value.isNotEmpty() && exchangeLocation.value.isNotEmpty() && exchangeTime2.value.isNotEmpty()) {

                                // Convierte los datos necesarios
                                val giftTopics = giftThemes.joinToString(", ")
                                val maxAmountDouble = maxAmount.value.toDoubleOrNull() ?: 0.0

                                // Llama a la función registerExchange
                                val success = dbHelper.registerExchange(
                                    participants = participants.joinToString(","),
                                    giftTopics = giftTopics,
                                    maxAmount = maxAmountDouble,
                                    registrationDeadline = exchangeDate1.value,
                                    exchangeDate = exchangeDate2.value,
                                    location = exchangeLocation.value,
                                    time = exchangeTime2.value,
                                    comments = additionalComments.value,
                                    email = userEmail
                                )

                                // Si se guarda correctamente, muestra el diálogo para seleccionar método de envío
                                if (success) {
                                    Toast.makeText(context, "Intercambio guardado exitosamente", Toast.LENGTH_LONG).show()

                                    // Mostrar diálogo para elegir el método de envío
                                    showSendOptionsDialog(context, nextExchangeId.value.toString(), participants, onNavigateToNextScreen)
                                } else {
                                    Toast.makeText(context, "Error al guardar el intercambio", Toast.LENGTH_LONG).show()
                                }
                            } else {
                                // Si algún campo está vacío
                                Toast.makeText(context, "Por favor, completa todos los campos obligatorios", Toast.LENGTH_LONG).show()
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Guardar y Enviar Código",
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Button(
                        onClick = onNavigateToNextScreen,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB71C1C))
                    ) {
                        Text(
                            text = "Regresar",
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

