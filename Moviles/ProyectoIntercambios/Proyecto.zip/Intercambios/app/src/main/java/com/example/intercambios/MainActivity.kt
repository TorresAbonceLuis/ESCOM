package com.example.intercambios

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import com.example.intercambios.data.DatabaseHelper
import com.example.intercambios.ui.theme.IntercambiosTheme
import com.example.intercambios.showSendOptionsDialog


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dbHelper = DatabaseHelper(this)

        setContent {
            IntercambiosTheme {
                var currentScreen by remember { mutableStateOf("login") }
                var participantesState by remember { mutableStateOf("") }
                var currentUserEmail by remember { mutableStateOf("") }
                var selectedExchangeId by remember { mutableStateOf("") }

                // Manejo de pantallas
                when (currentScreen) {
                    "login" -> LoginScreen(
                        onNavigateToNextScreen = { currentScreen = "next" },
                        onNavigateToRegister = { currentScreen = "register" },
                        dbHelper = dbHelper,
                        onUserLoggedIn = { email ->
                            currentUserEmail = email // Actualiza el correo del usuario
                        }
                    )
                    "register" -> RegisterScreen(
                        onNavigateToLogin = { currentScreen = "login" },
                        dbHelper = dbHelper
                    )
                    "next" -> NextScreen(
                        onNavigateToIntercambios = { currentScreen = "intercambios" },
                        onNavigateToMostrar = { currentScreen = "mostrar" }
                    )
                    "intercambios" -> IntercambiosScreen(
                        onNavigateToNextScreen = { currentScreen = "next" },
                        onNavigateToParticipantes = { currentScreen = "participantes" },
                        dbHelper = dbHelper,
                        userEmail = currentUserEmail
                    )
                    "mostrar" -> MostrarScreen(
                        onNavigateToNextScreen = { currentScreen = "next" },
                        dbHelper = dbHelper,
                        userEmail = currentUserEmail,
                        onNavigateToAdminScreen = { exchangeId ->
                            selectedExchangeId = exchangeId
                            currentScreen = "admin"
                        },
                        onNavigateToClienteScreen = { exchangeId ->
                            selectedExchangeId = exchangeId
                            currentScreen = "cliente"
                        }
                    )
                    "admin" -> AdminScreen(
                        exchangeId = selectedExchangeId,
                        onNavigateBack = { currentScreen = "mostrar" },
                        dbHelper = dbHelper
                    )
                    "cliente" -> ClienteScreen(
                        exchangeId = selectedExchangeId,
                        onNavigateBack = { currentScreen = "mostrar" },
                        dbHelper = dbHelper,
                        userEmail = currentUserEmail
                    )
                }
            }
        }
    }
}
