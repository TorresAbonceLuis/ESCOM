package com.example.intercambios

import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.example.intercambios.data.DatabaseHelper

@Composable
fun MainScreen(
    dbHelper: DatabaseHelper,
    modifier: Modifier = Modifier,
    onNavigateToNextScreen: () -> Unit, // Callback para navegación
    onUserLoggedIn: (String) -> Unit // Callback para actualizar el correo del usuario
) {
    var showLogin by remember { mutableStateOf(true) } // Controla si se muestra login o registro

    if (showLogin) {
        LoginScreen(
            onNavigateToNextScreen = {
                onNavigateToNextScreen() // Navega a la siguiente pantalla
            },
            onNavigateToRegister = { showLogin = false }, // Cambia a la pantalla de registro
            dbHelper = dbHelper,
            onUserLoggedIn = { email ->
                onUserLoggedIn(email) // Actualiza el correo del usuario logueado
            }
        )
    } else {
        RegisterScreen(
            onNavigateToLogin = { showLogin = true }, // Regresa a la pantalla de login
            dbHelper = dbHelper
        )
    }
}
