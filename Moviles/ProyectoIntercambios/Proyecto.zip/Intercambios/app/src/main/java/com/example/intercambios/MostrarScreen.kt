package com.example.intercambios

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.intercambios.data.DatabaseHelper
import androidx.compose.ui.platform.LocalContext

@Composable
fun MostrarScreen(
    onNavigateToNextScreen: () -> Unit,
    onNavigateToAdminScreen: (String) -> Unit, // Callback para navegar a AdminScreen
    onNavigateToClienteScreen: (String) -> Unit, // Callback para navegar a ClienteScreen
    dbHelper: DatabaseHelper,
    userEmail: String
) {
    val context = LocalContext.current

    val adminExchanges = remember { mutableStateOf<List<String>>(emptyList()) }
    val invitedExchanges = remember { mutableStateOf<List<String>>(emptyList()) }

    val showInputField = remember { mutableStateOf(false) } // Estado para mostrar el campo de entrada
    val inputValue = remember { mutableStateOf("") } // Estado para el valor del campo de entrada

    LaunchedEffect(Unit) {
        // Consultar intercambios donde el usuario es administrador
        adminExchanges.value = dbHelper.getAdminExchanges(userEmail)
        // Consultar intercambios donde el usuario es invitado
        invitedExchanges.value = dbHelper.getInvitedExchanges(userEmail)
    }

    Box(
        modifier = Modifier
            .fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.arbol),
            contentDescription = "Fondo de intercambios",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        Column(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .padding(16.dp)
                .background(Color.White.copy(alpha = 0.7f), shape = RoundedCornerShape(16.dp))
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Intercambios del Usuario: $userEmail",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFB71C1C),
                modifier = Modifier.padding(bottom = 16.dp)
            )

            // Sección de intercambios donde es administrador
            if (adminExchanges.value.isNotEmpty()) {
                Text(
                    text = "Admin",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF004D00),
                    modifier = Modifier.padding(vertical = 8.dp)
                )
                adminExchanges.value.forEach { exchangeId ->
                    Button(
                        onClick = { onNavigateToAdminScreen(exchangeId) }, // Navegar a AdminScreen
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF004D00))
                    ) {
                        Text(
                            text = "Intercambio $exchangeId",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 18.sp
                        )
                    }
                }
            }

            // Sección de intercambios donde es invitado
            if (invitedExchanges.value.isNotEmpty()) {
                Text(
                    text = "Invitado",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFB71C1C),
                    modifier = Modifier.padding(vertical = 8.dp)
                )
                invitedExchanges.value.forEach { exchangeId ->
                    Button(
                        onClick = { onNavigateToClienteScreen(exchangeId) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB71C1C))
                    ) {
                        Text(
                            text = "Intercambio $exchangeId",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 18.sp
                        )
                    }
                }
            }

            // Botón para ingresar a un intercambio
            Button(
                onClick = { showInputField.value = !showInputField.value }, // Mostrar/Ocultar campo
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF004D00))
            ) {
                Text(
                    text = "Ingresar a Intercambio",
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    fontSize = 18.sp
                )
            }

            // Campo de texto y botón "Ingresar" visibles al presionar el botón
            if (showInputField.value) {
                OutlinedTextField(
                    value = inputValue.value,
                    onValueChange = { newValue ->
                        inputValue.value = newValue.filter { it.isDigit() } // Solo permite números
                    },
                    label = { Text("ID del Intercambio", color = Color.Black) },
                    keyboardOptions = KeyboardOptions.Default.copy(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    textStyle = LocalTextStyle.current.copy(color = Color.Black)
                )

                // Botón "Ingresar" debajo del campo de texto
                Button(
                    onClick = {
                        val exchangeId = inputValue.value.trim()
                        if (exchangeId.isNotEmpty()) {
                            // Llamar a la función de la base de datos para agregar al usuario
                            val success = dbHelper.addParticipantToExchange(exchangeId, userEmail)
                            if (success) {
                                Toast.makeText(context, "Se agregó correctamente al intercambio.", Toast.LENGTH_SHORT).show()

                                // Actualizar las listas de intercambios
                                adminExchanges.value = dbHelper.getAdminExchanges(userEmail)
                                invitedExchanges.value = dbHelper.getInvitedExchanges(userEmail)

                                // Limpiar el campo de texto y ocultar el formulario
                                inputValue.value = ""
                                showInputField.value = false
                            } else {
                                Toast.makeText(context, "No se encontró el intercambio o ya estás registrado.", Toast.LENGTH_SHORT).show()
                            }
                        } else {
                            Toast.makeText(context, "Por favor, ingresa un ID válido.", Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF004D00))
                ) {
                    Text(
                        text = "Ingresar",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 18.sp
                    )
                }
            }
            Button(
                onClick = onNavigateToNextScreen,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB71C1C))
            ) {
                Text(
                    text = "Regresar",
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    fontSize = 18.sp
                )
            }
        }
    }
}
