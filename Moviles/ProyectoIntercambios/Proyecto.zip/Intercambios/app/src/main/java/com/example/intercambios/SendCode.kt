package com.example.intercambios

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.*
import javax.mail.Authenticator
import javax.mail.Message
import javax.mail.PasswordAuthentication
import javax.mail.Session
import javax.mail.Transport
import javax.mail.internet.InternetAddress
import javax.mail.internet.MimeMessage

fun showSendOptionsDialog(
    context: Context,
    code: String, // Código a enviar
    participants: List<Map<String, String>>, // Lista de participantes con "correo" y "telefono"
    onNavigateToNextScreen: () -> Unit // Callback para navegar a la siguiente pantalla
) {
    val options = arrayOf("Correo", "SMS", "WhatsApp")
    AlertDialog.Builder(context)
        .setTitle("¿Cómo deseas enviar el código?")
        .setItems(options) { _, which ->
            when (which) {
                0 -> sendEmails(context, code, participants.mapNotNull { it["correo"] }, onNavigateToNextScreen)
                1 -> sendSmsToParticipants(context, code, participants.mapNotNull { it["telefono"] }, onNavigateToNextScreen)
                2 -> sendWhatsAppMessages(context, code, participants, onNavigateToNextScreen)
            }
        }
        .show()
}

fun sendEmails(context: Context, code: String, emails: List<String>, onNavigateToNextScreen: () -> Unit) {
    val email = "luiseishon9@gmail.com" // Cambiar por tu correo Gmail
    val password = "sley ihsk kjdp eqbx" // Contraseña generada para aplicaciones
    val subject = "Código de Intercambio"
    val body = "Tu código para ingresar al intercambio es: $code"

    emails.forEach { recipient ->
        CoroutineScope(Dispatchers.IO).launch {
            val success = sendGmail(email, password, recipient, subject, body)
            withContext(Dispatchers.Main) {
                Toast.makeText(context, if (success) "Correo enviado a $recipient" else "Error al enviar a $recipient", Toast.LENGTH_SHORT).show()
            }
        }
    }
    onNavigateToNextScreen()
}

suspend fun sendGmail(email: String, password: String, toEmail: String, subject: String, body: String): Boolean {
    return withContext(Dispatchers.IO) {
        try {
            val props = Properties().apply {
                put("mail.smtp.auth", "true")
                put("mail.smtp.starttls.enable", "true")
                put("mail.smtp.host", "smtp.gmail.com")
                put("mail.smtp.port", "587")
            }

            val session = Session.getInstance(props, object : Authenticator() {
                override fun getPasswordAuthentication(): PasswordAuthentication {
                    return PasswordAuthentication(email, password)
                }
            })

            val message = MimeMessage(session).apply {
                setFrom(InternetAddress(email))
                setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail))
                this.subject = subject
                setText(body)
            }

            Transport.send(message)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}

fun sendSmsToParticipants(context: Context, code: String, phoneNumbers: List<String>,onNavigateToNextScreen: () -> Unit) {
    phoneNumbers.forEach { phoneNumber ->
        try {
            val smsManager = android.telephony.SmsManager.getDefault()
            smsManager.sendTextMessage(phoneNumber, null, "Tu código para ingresar al intercambio es: $code", null, null)
            Toast.makeText(context, "SMS enviado a $phoneNumber", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "Error al enviar SMS a $phoneNumber", Toast.LENGTH_SHORT).show()
        }
    }
    onNavigateToNextScreen()
}

fun sendWhatsAppMessages(
    context: Context,
    code: String,
    participants: List<Map<String, String>>,
    onNavigateToNextScreen: () -> Unit
) {
    // Crear un diálogo personalizado
    val builder = AlertDialog.Builder(context)
    builder.setTitle("Enviar mensajes por WhatsApp")

    // Crear una lista de vistas personalizadas
    val container = android.widget.LinearLayout(context).apply {
        orientation = android.widget.LinearLayout.VERTICAL
        setPadding(16, 16, 16, 16)
    }

    participants.forEach { participant ->
        val name = participant["nombre"] ?: "Sin nombre"
        val phoneNumber = participant["telefono"] ?: "Sin teléfono"
        val fullNumber = if (phoneNumber.startsWith("+")) phoneNumber else "+52$phoneNumber"

        // Fila para cada participante
        val row = android.widget.LinearLayout(context).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            setPadding(0, 8, 0, 8)
        }

        // Nombre y teléfono
        val participantInfo = android.widget.TextView(context).apply {
            text = "$name ($phoneNumber)"
            layoutParams = android.widget.LinearLayout.LayoutParams(0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        // Botón para enviar mensaje
        val sendButton = android.widget.Button(context).apply {
            text = "Enviar mensaje"
            setOnClickListener {
                if (!isWhatsAppInstalled(context)) {
                    Toast.makeText(context, "WhatsApp no está instalado", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                try {
                    val message = "Tu código para ingresar al intercambio es: $code"
                    val uri = Uri.parse("https://wa.me/$fullNumber?text=${Uri.encode(message)}")
                    val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                        setPackage("com.whatsapp")
                    }
                    context.startActivity(intent)
                } catch (e: Exception) {
                    e.printStackTrace()
                    Toast.makeText(context, "Error al enviar mensaje a $phoneNumber", Toast.LENGTH_SHORT).show()
                }
            }
        }

        // Agregar vistas a la fila
        row.addView(participantInfo)
        row.addView(sendButton)

        // Agregar fila al contenedor
        container.addView(row)
    }

    builder.setView(container)
    builder.setPositiveButton("Cerrar") { dialog, _ ->
        dialog.dismiss()
        onNavigateToNextScreen()
    }

    // Mostrar diálogo
    builder.show()
}

fun isWhatsAppInstalled(context: Context): Boolean {
    return try {
        context.packageManager.getPackageInfo("com.whatsapp", 0)
        true
    } catch (e: Exception) {
        false
    }
}
