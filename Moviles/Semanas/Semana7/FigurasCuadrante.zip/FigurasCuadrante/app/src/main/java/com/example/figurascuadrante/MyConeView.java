package com.example.figurascuadrante;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.opengl.GLU;
import android.util.AttributeSet;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import javax.microedition.khronos.opengles.GL10;

public class MyConeView extends GLSurfaceView {
    public MyConeView(Context context) {
        super(context);
        setRenderer(new MyConeRenderer());
    }

    public MyConeView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setRenderer(new MyConeRenderer());
    }

    private class MyConeRenderer implements Renderer {
        private Cone cone;
        private float angle;

        @Override
        public void onSurfaceCreated(GL10 gl, EGLConfig config) {
            gl.glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
            cone = new Cone();
        }

        @Override
        public void onSurfaceChanged(GL10 gl, int width, int height) {
            gl.glViewport(0, 0, width, height);
            gl.glMatrixMode(GL10.GL_PROJECTION);
            gl.glLoadIdentity();
            GLU.gluPerspective(gl, 45.0f, (float) width / (float) height, 0.1f, 100.0f);
            gl.glMatrixMode(GL10.GL_MODELVIEW);
            gl.glLoadIdentity();
        }

        @Override
        public void onDrawFrame(GL10 gl) {
            gl.glClear(GL10.GL_COLOR_BUFFER_BIT | GL10.GL_DEPTH_BUFFER_BIT);
            gl.glLoadIdentity();
            GLU.gluLookAt(gl, 0, 0, -3, 0f, 0f, 0f, 0f, 1.0f, 0.0f);

            // Escala el cono para hacerlo más pequeño
            gl.glScalef(0.4f, 0.4f, 0.4f);

            // Rota el cono en diagonal
            gl.glRotatef(angle, 1.0f, 1.0f, 1.0f);

            cone.draw(gl);

            // Incrementa el ángulo para la próxima vez que se dibuje el cono
            angle += 1.0f;
        }
    }
}
class Cone {
    private FloatBuffer vertexBuffer;
    private int numVertices;

    public Cone() {
        int numFaces = 30;
        numVertices = numFaces + 2;

        float vertices[] = new float[numVertices * 3];

        // Define the vertices for the top of the cone
        vertices[0] = 0;
        vertices[1] = 1;
        vertices[2] = 0;

        // Define the vertices for the base of the cone
        float angleStep = (float) (2.0 * Math.PI / numFaces);
        float angle = 0;
        for (int i = 3; i < vertices.length; i += 3) {
            vertices[i] = (float) Math.sin(angle);
            vertices[i + 1] = -1;
            vertices[i + 2] = (float) Math.cos(angle);
            angle += angleStep;
        }

        // Convert the vertices to a FloatBuffer
        ByteBuffer vbb = ByteBuffer.allocateDirect(vertices.length * 4);
        vbb.order(ByteOrder.nativeOrder());
        vertexBuffer = vbb.asFloatBuffer();
        vertexBuffer.put(vertices);
        vertexBuffer.position(0);
    }

    public void draw(GL10 gl) {
        gl.glFrontFace(GL10.GL_CCW);
        gl.glEnableClientState(GL10.GL_VERTEX_ARRAY);
        gl.glVertexPointer(3, GL10.GL_FLOAT, 0, vertexBuffer);

        // Draw the top of the cone
        gl.glDrawArrays(GL10.GL_TRIANGLE_FAN, 0, numVertices);

        // Draw the base of the cone
        gl.glDrawArrays(GL10.GL_TRIANGLE_FAN, 1, numVertices - 1);

        gl.glDisableClientState(GL10.GL_VERTEX_ARRAY);
    }
}
