package com.example.figurascuadrante;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.opengl.GLU;
import android.util.AttributeSet;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;
class MyCustomRenderer implements GLSurfaceView.Renderer {
    private Cube cube;
    private float rotationAngle = 0.0f;

    public MyCustomRenderer() {
        cube = new Cube();
    }

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        gl.glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
        gl.glClearDepthf(1.0f);
        gl.glEnable(GL10.GL_DEPTH_TEST);
        gl.glDepthFunc(GL10.GL_LEQUAL);
        gl.glHint(GL10.GL_PERSPECTIVE_CORRECTION_HINT, GL10.GL_NICEST);
        gl.glShadeModel(GL10.GL_SMOOTH);
        gl.glDisable(GL10.GL_DITHER);
        gl.glDisable(GL10.GL_LIGHTING); // Desactivar la iluminación
    }

    @Override
public void onDrawFrame(GL10 gl) {
    gl.glClear(GL10.GL_COLOR_BUFFER_BIT | GL10.GL_DEPTH_BUFFER_BIT);
    gl.glLoadIdentity();
    gl.glTranslatef(0.0f, 0.0f, -6.0f);
    gl.glRotatef(rotationAngle, 1.0f, 1.0f, 1.0f); // Rotar el cubo
    cube.draw(gl);
    rotationAngle += 0.5f; // Incrementar el ángulo de rotación
}

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        gl.glViewport(0, 0, width, height);
        gl.glMatrixMode(GL10.GL_PROJECTION);
        gl.glLoadIdentity();
        GLU.gluPerspective(gl, 45.0f, (float) width / (float) height, 0.1f, 100.0f);
        gl.glMatrixMode(GL10.GL_MODELVIEW);
        gl.glLoadIdentity();
    }
}

class Cube {
    public void draw(GL10 gl) {
        // Define the vertices of the cube
        float vertices[] = {
                -1, -1, -1, // 0
                1, -1, -1,  // 1
                1, 1, -1,   // 2
                -1, 1, -1,  // 3
                -1, -1, 1,  // 4
                1, -1, 1,   // 5
                1, 1, 1,    // 6
                -1, 1, 1    // 7
        };

        // Define the vertex indices for the cube's faces
        byte indices[] = {
                0, 4, 5, 0, 5, 1,   // Front face
                1, 5, 6, 1, 6, 2,   // Right face
                2, 6, 7, 2, 7, 3,   // Back face
                3, 7, 4, 3, 4, 0,   // Left face
                4, 7, 6, 4, 6, 5,   // Top face
                3, 0, 1, 3, 1, 2    // Bottom face
        };

        // Set the color for the cube (R,G,B,A)
        float colors[] = {
                1, 0, 0, 1, // Red
                0, 1, 0, 1, // Green
                0, 0, 1, 1, // Blue
                1, 1, 0, 1, // Yellow
                1, 0, 1, 1, // Magenta
                0, 1, 1, 1  // Cyan
        };

        // Convertir los arrays a buffers
        ByteBuffer vbb = ByteBuffer.allocateDirect(vertices.length * 4);

        vbb.order(ByteOrder.nativeOrder());
        FloatBuffer vertexBuffer = vbb.asFloatBuffer();
        vertexBuffer.put(vertices);
        vertexBuffer.position(0);

        ByteBuffer cbb = ByteBuffer.allocateDirect(colors.length * 4);
        cbb.order(ByteOrder.nativeOrder());
        FloatBuffer colorBuffer = cbb.asFloatBuffer();
        colorBuffer.put(colors);
        colorBuffer.position(0);

        ByteBuffer ibb = ByteBuffer.allocateDirect(indices.length * 1); // Utiliza 1 byte por índice

        ibb.order(ByteOrder.nativeOrder());
        ByteBuffer indexBuffer = ibb;
        indexBuffer.put(indices);
        indexBuffer.position(0);

        gl.glScalef(0.5f, 0.5f, 0.5f);
        gl.glFrontFace(GL10.GL_CCW);
        gl.glEnableClientState(GL10.GL_VERTEX_ARRAY);
        gl.glEnableClientState(GL10.GL_COLOR_ARRAY);
        gl.glVertexPointer(3, GL10.GL_FLOAT, 0, vertexBuffer);
        gl.glColorPointer(4, GL10.GL_FLOAT, 0, colorBuffer);
        gl.glDrawElements(GL10.GL_TRIANGLES, indices.length, GL10.GL_UNSIGNED_BYTE, indexBuffer);
    }
}

public class MyCustomView extends GLSurfaceView {
    public MyCustomView(Context context) {
        super(context);
        setRenderer(new MyCustomRenderer());
    }

    public MyCustomView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setRenderer(new MyCustomRenderer());
    }
}