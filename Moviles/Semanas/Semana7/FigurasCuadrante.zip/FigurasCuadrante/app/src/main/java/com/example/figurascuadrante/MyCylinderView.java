package com.example.figurascuadrante;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.opengl.GLU;
import android.util.AttributeSet;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class MyCylinderView extends GLSurfaceView {
    public MyCylinderView(Context context) {
        super(context);
        setRenderer(new MyCylinderRenderer());
    }

    public MyCylinderView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setRenderer(new MyCylinderRenderer());
    }

    private class MyCylinderRenderer implements Renderer {
        private Cylinder cylinder;

        float angle = 0.0f;

        @Override
        public void onSurfaceCreated(GL10 gl, EGLConfig config) {
            gl.glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
            cylinder = new Cylinder();
        }

        @Override
        public void onSurfaceChanged(GL10 gl, int width, int height) {
            gl.glViewport(0, 0, width, height);
            gl.glMatrixMode(GL10.GL_PROJECTION);
            gl.glLoadIdentity();
            GLU.gluPerspective(gl, 45.0f, (float) width / (float) height, 0.1f, 100.0f);
            gl.glMatrixMode(GL10.GL_MODELVIEW);
            gl.glLoadIdentity();
        }

        @Override
        public void onDrawFrame(GL10 gl) {
            gl.glClear(GL10.GL_COLOR_BUFFER_BIT | GL10.GL_DEPTH_BUFFER_BIT);
            gl.glLoadIdentity();
            GLU.gluLookAt(gl, 0, 0, -3, 0f, 0f, 0f, 0f, 1.0f, 0.0f);

            // Escala el cilindro para hacerlo más pequeño
            gl.glScalef(0.3f, 0.3f, 0.3f);

            // Rota el cilindro en diagonal
            gl.glRotatef(angle, 1.0f, 1.0f, 1.0f);

            cylinder.draw(gl);

            // Incrementa el ángulo para la próxima vez que se dibuje el cilindro
            angle += 1.0f;
        }
    }
}

class Cylinder {
    private FloatBuffer vertexBuffer;
    private FloatBuffer baseBuffer;
    private int numVertices;

    public Cylinder() {
        int numFaces = 30;
        numVertices = numFaces * 2;

        float vertices[] = new float[(numVertices + 2) * 3];
        float baseVertices[] = new float[(numFaces + 2) * 2 * 3];

        // Define the vertices for the top and bottom of the cylinder
        float angleStep = (float) (2.0 * Math.PI / numFaces);
        float angle = 0;
        for (int i = 0; i < vertices.length; i += 6) {
            float x = (float) Math.sin(angle);
            float z = (float) Math.cos(angle);

            vertices[i] = x;
            vertices[i + 1] = 1;
            vertices[i + 2] = z;

            vertices[i + 3] = x;
            vertices[i + 4] = -1;
            vertices[i + 5] = z;

            angle += angleStep;
        }

        // Close the loop
        vertices[vertices.length - 6] = vertices[0];
        vertices[vertices.length - 5] = vertices[1];
        vertices[vertices.length - 4] = vertices[2];
        vertices[vertices.length - 3] = vertices[3];
        vertices[vertices.length - 2] = vertices[4];
        vertices[vertices.length - 1] = vertices[5];

        // Define the vertices for the base of the cylinder
        for (int i = 0; i <= numFaces; i++) {
            angle = i * angleStep;
            baseVertices[i * 3] = (float) Math.sin(angle);
            baseVertices[i * 3 + 1] = -1;
            baseVertices[i * 3 + 2] = (float) Math.cos(angle);

            baseVertices[(i + numFaces + 1) * 3] = (float) Math.sin(angle);
            baseVertices[(i + numFaces + 1) * 3 + 1] = 1;
            baseVertices[(i + numFaces + 1) * 3 + 2] = (float) Math.cos(angle);
        }

        // Convert the vertices to a FloatBuffer
        ByteBuffer vbb = ByteBuffer.allocateDirect(vertices.length * 4);
        vbb.order(ByteOrder.nativeOrder());
        vertexBuffer = vbb.asFloatBuffer();
        vertexBuffer.put(vertices);
        vertexBuffer.position(0);

        ByteBuffer bbb = ByteBuffer.allocateDirect(baseVertices.length * 4);
        bbb.order(ByteOrder.nativeOrder());
        baseBuffer = bbb.asFloatBuffer();
        baseBuffer.put(baseVertices);
        baseBuffer.position(0);
    }

    public void draw(GL10 gl) {
        gl.glFrontFace(GL10.GL_CCW);
        gl.glEnableClientState(GL10.GL_VERTEX_ARRAY);

        // Draw the lateral surface of the cylinder
        gl.glVertexPointer(3, GL10.GL_FLOAT, 0, vertexBuffer);
        gl.glDrawArrays(GL10.GL_TRIANGLE_STRIP, 0, numVertices + 2);

        // Draw the top and bottom of the cylinder
        gl.glVertexPointer(3, GL10.GL_FLOAT, 0, baseBuffer);
        gl.glDrawArrays(GL10.GL_TRIANGLE_FAN, 0, numVertices / 2 + 1);
        gl.glDrawArrays(GL10.GL_TRIANGLE_FAN, numVertices / 2 + 1, numVertices / 2 + 1);

        gl.glDisableClientState(GL10.GL_VERTEX_ARRAY);
    }
}