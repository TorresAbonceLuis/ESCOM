package com.example.figurascuadrante;
import android.content.Context;
import android.opengl.GLSurfaceView;
import android.opengl.GLU;
import android.util.AttributeSet;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

public class MySphereView extends GLSurfaceView {
    public MySphereView(Context context) {
        super(context);
        setRenderer(new MySphereRenderer());
    }

    public MySphereView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setRenderer(new MySphereRenderer());
    }
}

class MySphereRenderer implements GLSurfaceView.Renderer {
    private Sphere sphere;
    private float angle;

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        sphere = new Sphere();
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        gl.glViewport(0, 0, width, height);
        gl.glMatrixMode(GL10.GL_PROJECTION);
        gl.glLoadIdentity();
        GLU.gluPerspective(gl, 45.0f, (float) width / (float) height, 0.1f, 100.0f);
        gl.glMatrixMode(GL10.GL_MODELVIEW);
        gl.glLoadIdentity();
    }

    @Override
    public void onDrawFrame(GL10 gl) {
        gl.glClear(GL10.GL_COLOR_BUFFER_BIT | GL10.GL_DEPTH_BUFFER_BIT);
        gl.glLoadIdentity();
        GLU.gluLookAt(gl, 0, 0, -3, 0f, 0f, 0f, 0f, 1.0f, 0.0f);

        // Escala la esfera para hacerla más pequeña
        gl.glScalef(0.3f, 0.3f, 0.3f);

        // Rota la esfera
        gl.glRotatef(angle, 1.0f, 1.0f, 1.0f);

        sphere.draw(gl);

        // Incrementa el ángulo para la próxima vez que se dibuje la esfera
        angle += 1.0f;
    }
}

class Sphere {
    private FloatBuffer vertexBuffer;
    private FloatBuffer colorBuffer; // Nuevo buffer para los colores
    private int numVertices;

    public Sphere() {
        int numSlices = 30;
        int numStacks = 30;
        numVertices = numSlices * numStacks * 6;

        float vertices[] = new float[numVertices * 3];
        float colors[] = new float[numVertices * 4]; // Nuevo array para los colores

        int index = 0;
        int colorIndex = 0;
        for (int stack = 0; stack < numStacks; stack++) {
            float stackRatio = (float) stack / (float) (numStacks - 1);
            float stackAngle = (float) (Math.PI * stackRatio);
            float y = (float) Math.cos(stackAngle);
            float stackRadius = (float) Math.sin(stackAngle);

            for (int slice = 0; slice < numSlices; slice++) {
                float sliceRatio = (float) slice / (float) numSlices;
                float sliceAngle = (float) (2.0 * Math.PI * sliceRatio);
                float x = stackRadius * (float) Math.sin(sliceAngle);
                float z = stackRadius * (float) Math.cos(sliceAngle);

                vertices[index++] = x;
                vertices[index++] = y;
                vertices[index++] = z;

                // Asignar colores de manera cíclica
                colors[colorIndex++] = 1.0f; // Red
                colors[colorIndex++] = (slice % 2 == 0) ? 1.0f : 0.0f; // Green
                colors[colorIndex++] = (stack % 2 == 0) ? 1.0f : 0.0f; // Blue
                colors[colorIndex++] = 1.0f; // Alpha
            }
        }

        ByteBuffer vbb = ByteBuffer.allocateDirect(vertices.length * 4);
        vbb.order(ByteOrder.nativeOrder());
        vertexBuffer = vbb.asFloatBuffer();
        vertexBuffer.put(vertices);
        vertexBuffer.position(0);

        ByteBuffer cbb = ByteBuffer.allocateDirect(colors.length * 4);
        cbb.order(ByteOrder.nativeOrder());
        colorBuffer = cbb.asFloatBuffer();
        colorBuffer.put(colors);
        colorBuffer.position(0);
    }

    public void draw(GL10 gl) {
        gl.glFrontFace(GL10.GL_CCW);
        gl.glEnableClientState(GL10.GL_VERTEX_ARRAY);
        gl.glEnableClientState(GL10.GL_COLOR_ARRAY); // Habilitar el array de colores

        gl.glVertexPointer(3, GL10.GL_FLOAT, 0, vertexBuffer);
        gl.glColorPointer(4, GL10.GL_FLOAT, 0, colorBuffer); // Asignar el buffer de colores

        for (int i = 0; i < numVertices; i += 6) {
            gl.glDrawArrays(GL10.GL_TRIANGLE_FAN, i, 6);
        }

        gl.glDisableClientState(GL10.GL_VERTEX_ARRAY);
        gl.glDisableClientState(GL10.GL_COLOR_ARRAY); // Deshabilitar el array de colores
    }
}